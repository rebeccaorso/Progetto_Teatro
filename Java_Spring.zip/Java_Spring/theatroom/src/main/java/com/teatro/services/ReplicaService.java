package com.teatro.services;

import java.util.List;

import com.teatro.entities.Replica;

public interface ReplicaService {

	List<Replica> getReplica();
}
