package com.teatro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatroomApplication.class, args);
	}

}
