package com.teatro.services;

import java.util.List;

import com.teatro.entities.Teatro;

public interface TeatroService {
	
	List<Teatro> getTeatro();
}
